# NARBE Trinkey Configurator entry point. No automatic reset on HID count.
import narbe_runtime
narbe_runtime.run()
